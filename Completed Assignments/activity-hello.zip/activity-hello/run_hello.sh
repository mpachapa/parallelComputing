#!/bin/sh
make hello
./hello > hello_answer
